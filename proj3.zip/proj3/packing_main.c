#include "packing.h"

int main(int argc, char **argv)
{
	char * load_file = argv[1];
	char * save_file = argv[2];
	BSTNode * root = NULL;
	BSTNode * head = NULL;
	BSTNode * maxNum = NULL;
	BSTNode ** list = malloc(sizeof(BSTNode*));
	head = loadFromFile(load_file);
	* list = head;
	root = buildBST(list,root);
	pack(root, 0, 0);
	maxNum = Save_To_File(save_file, root);
	printf("Width: %le\nHeight: %le\n",root -> width, root -> height);
	printf("X-coordinate: %le\nY-coordinate: %le\n",maxNum -> x, maxNum -> y);
	destroyBST(root);
	free(list);
	
	
}
