#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <time.h>


typedef struct _BST_Node{
	char HV;//either H or V fro a cut or N for a number node
	int rectNum;//the label of the node
	double width;//width of node
	double height;//height of node
	double x;//x cord of node
	double y;//y cord
	struct _BST_Node * left;//pointers left
	struct _BST_Node * right;//pointer right
} BSTNode;


BSTNode * pack(BSTNode * node, double fixY, double fixX);
void destroyBST(BSTNode * root);
void printInorder(BSTNode * node);
BSTNode * buildBST(BSTNode ** head, BSTNode * root);
BSTNode * loadFromFile(char * Filename);
BSTNode * Save_To_File(char *Filename, BSTNode * root);


