#include "packing.h"
#define CHAR_OFF_SET 48

BSTNode * addToBST(BSTNode * root, BSTNode * node);
BSTNode * createBSTNode(char HV, int num, double height, double width);
BSTNode * addToList(BSTNode * root, BSTNode * node);
BSTNode * printNodes(FILE * fp,BSTNode * curr);
void printList(BSTNode * root);
void freeList(BSTNode * root);

//saves the files of filename the number nodes of the BST and return the largest indexed node
BSTNode * Save_To_File(char *Filename, BSTNode * root)
{	
	BSTNode * maxNum = NULL;
	if(root == NULL)
	{
		return NULL;
	}
	FILE * fp = NULL;
	fp = fopen(Filename, "w");
	if(fp == NULL)
	{
		printf("\nSave to file: fopen error\n"); 
		return NULL;
	}
	maxNum = printNodes(fp,root);
	fclose(fp);
	return maxNum;
}

//prints the nodes to a file at the fp and returns the node with the largest index
BSTNode * printNodes(FILE * fp, BSTNode * curr)
{
	
	BSTNode * right = NULL;
	BSTNode * left = NULL;
	if(curr == NULL)
	{
		return NULL;
	}
	left = printNodes(fp,curr -> left);
	if(curr -> HV == 'N')
	{
		fprintf(fp,"%d %le %le %le %le\n",curr -> rectNum, curr -> width, curr -> height, curr -> x, curr -> y);
	}
	right = printNodes(fp,curr -> right);
	if(right != NULL && left != NULL)
	{
		if(right ->rectNum >= left -> rectNum)
		{
			return right;
		}
		return left;
	}
	return curr;
}

//packs the BST based on the parent V or H and the width and height of the left or right nodes.
//The fix value to to fix the coordinates of the number nodes when calculating down the tree.
//
BSTNode * pack(BSTNode * node, double fixY, double fixX){
	//returns the node if it is a number node	
	if(node -> HV == 'N')
	{
		return node;
	}
	//if the node is a vertical cut
	else if(node -> HV == 'V')\
	{
		pack(node -> left, fixY, fixX);
		pack(node -> right, fixY, fixX + (node -> left -> width));
		//set node width and height. Width is the sum of both widths
		node -> width = (node -> left -> width) + (node -> right -> width);
		//node height is the max of the left and right
		if((node -> left -> height) >= (node -> right -> height))
		{
			node -> height = node -> left -> height;
		}
		else
		{
			node -> height = node -> right -> height;
		}
		//sets the coodinates of the node, adds fix if it is non 0
		node -> right -> x = fixX + (node -> left -> width);
		node -> left -> x = fixX;
		node -> right -> y = fixY;
		node -> left -> y = fixY;
	}
	//if the node is a horizontal cut
	else
	{
		pack(node -> right, fixY, fixX);
		pack(node -> left, fixY + (node -> right -> height), fixX);
		//set node width and height
		node -> height = (node -> left -> height) + (node -> right -> height);
		if((node -> left -> width) >= (node -> right -> width))
		{
			node -> width = node -> left -> width;
		}
		else
		{
			node -> width = node -> right -> width;
		}
		//sets the coodinates of the node, adds fix if it is non 0
		node -> left -> y = fixY + (node -> right -> height);
		node -> right -> y = fixY;
		node -> left -> x = fixX;
		node -> right -> x = fixX;
	}
	return node;
}

//builds the BST at the root node. BSTNode ** head is the top of the stack of nodes to be put into the BST
BSTNode * buildBST(BSTNode ** head, BSTNode * root){
	if(root == NULL)
	{
		root = (*head);
		(*head) = (*head) -> right;
		root -> right = NULL;
	}
	if(root -> HV == 'N')
	{
		return root;
	}
	root -> right = buildBST(head, root -> right);
	root -> left = buildBST(head, root -> left);
	return root;
}

//prints BST order
void printInorder(BSTNode * curr)
{
	if(curr == NULL)
	{
		return;
	}
	printInorder(curr -> left);
	printf("char: %c num: %d wid: %lf hit: %lf x: %lf y: %lf \n",curr-> HV, curr -> rectNum, curr -> width, curr -> height, curr -> x, curr -> y);
	printInorder(curr -> right);
}

//loads the data from filename into a stack of BSTNodes and retruns the stack
BSTNode * loadFromFile(char * filename){
	FILE * fp = NULL;
	fp = fopen(filename, "r");
	if(fp == NULL)
	{
		printf("\nload from file: fopen error\n"); 
		return NULL;
	}
	fseek(fp,0,SEEK_END);
	int size = ftell(fp);
	fseek(fp,0,SEEK_SET);
	int rectNum = 0;
	double height = 0;
	double width = 0;
	BSTNode * root = NULL;
	while(ftell(fp) < size)
	{
		rectNum = fgetc(fp);
		//if the first char of the line is a V or H creates a V or H node.
		if(rectNum == 'V' || rectNum == 'H')
		{
			BSTNode * add = createBSTNode(rectNum , 0 , 0 , 0);
			root = addToList(root, add);
		}
		else//creates a number node
		{
			fseek(fp, 1, SEEK_CUR);
			if(fscanf(fp,"%le",&width) != 1)
			{
				printf("\nerror load: fscnf width\n");
				return NULL;
			}
			fseek(fp, 1, SEEK_CUR);
			if(fscanf(fp,"%le",&height) != 1)
			{
				printf("\nerror load: fscnf height\n");
				return NULL;
			}
			fseek(fp, 1, SEEK_CUR);
			BSTNode * add = createBSTNode('N', rectNum - CHAR_OFF_SET, height , width);
			root = addToList(root, add);
		}
		fseek(fp, 1, SEEK_CUR);
	}
	fclose(fp);
	return root;
}

//frees the BST
void destroyBST(BSTNode * node){
	if(node)
	{
		destroyBST(node -> left);
		destroyBST(node -> right);
		free(node);
	}
}


//initailizes and mallocs a BSTNode
BSTNode * createBSTNode(char hv, int num, double hit, double wid){
	BSTNode * add = malloc(sizeof(BSTNode));
	if(add == NULL)
	{
		printf("\ncreate BST error: malloc\n"); 
		return NULL;
	}
	add -> right = NULL;
	add -> left = NULL;
	add -> HV = hv;
	add -> rectNum = num;
	add -> height = hit;
	add -> width = wid;
	add -> x = 0;
	add -> y = 0;
	return add;
}

//adds to the satck used to craete BST
BSTNode * addToList(BSTNode * root, BSTNode * add){
	if(root == NULL)
	{
		root = add;
	}
	else
	{
		
		add -> right = root;
		root = add;
	}
	return root;
}

//prints the stack used to create the BST
void printList(BSTNode * root){
	printf("\nprintlist:\n");
	if(root == NULL)
	{
		printf("list is empty\n");
	}
	else
	{
		BSTNode * curr = root;
		while(curr !=NULL)
		{
			printf("char: %c num: %d wid: %lf hit: %lf x: %lf y: %lf \n",curr-> HV, curr -> rectNum, curr -> width, curr -> height, curr -> x, curr -> y);
			curr = curr -> right;
		}
	}
}
